package com.example.jamali_bro.payingguestapp;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity{
    Button login,signup;
    EditText mail,password;
    private FirebaseAuth mAuth;
    private ProgressDialog mbar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Sign In");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mAuth = FirebaseAuth.getInstance();
        login = (Button)findViewById(R.id.loginn);
        signup=(Button)findViewById(R.id.createaccount);
        mail=(EditText)findViewById(R.id.usernamelogin);
        password=(EditText)findViewById(R.id.passwordlogin);
        mbar=new ProgressDialog(this);
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                signIn();
            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Login.this, CreateAccount.class);
                startActivity(intent);
            }
        });

    }
    private boolean validateForm() {
        boolean result = true;
        if (TextUtils.isEmpty(mail.getText().toString())) {
            mail.setError("Required");
            result = false;
        } else {
            mail.setError(null);
        }

        if (TextUtils.isEmpty(password.getText().toString())) {
            password.setError("Required");
            result = false;
        } else {
            password.setError(null);
        }
        return result;
    }
    public void signIn()
    {
        if (!validateForm()) {
            return;
        }
        mbar.setMessage("Signing In");
        mbar.show();
        String email=mail.getText().toString();
        String pass=password.getText().toString();
        mAuth.signInWithEmailAndPassword(email, pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Log.d("TAG", "signInWithEmail:success");
                            mbar.dismiss();
                            FirebaseUser user = mAuth.getCurrentUser();
                            Intent post=new Intent(Login.this,HostActivity.class);
                            startActivity(post);

                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("TAG", "signInWithEmail:failure", task.getException());
                            Toast.makeText(Login.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                            mbar.setMessage("Sign In Failed..");
                            mbar.dismiss();
                            //Intent account=new Intent(Login.this,CreateAccount.class);
                            //startActivity(account);

                        }

                        // ...
                    }
                });
    }
}
