package com.example.jamali_bro.payingguestapp;

import android.content.Intent;

import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import android.util.Log;

import com.google.android.gms.common.api.Status;

import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.HashMap;

import java.util.Map;

public class MapsActivity extends FragmentActivity implements GoogleMap.OnMarkerClickListener,OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {

    private GoogleMap mMap;
    private PlaceAutocompleteFragment autocompleteFragment;
    Double longitude=0.0,latitude=0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);

        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                Log.i("TAG", "Place: " + place.getName());
                longitude=place.getLatLng().longitude;
                latitude=place.getLatLng().latitude;
                mMap.addMarker(new MarkerOptions().position(new LatLng(latitude,longitude))
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
                mMap.animateCamera(CameraUpdateFactory.newLatLng(new LatLng(latitude,longitude)));
                float zoomLevel = 10.0f; //This goes up to 21
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude,longitude), zoomLevel));
            }

            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
                Log.i("TAG", "An error occurred: " + status);
            }
        });


       SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMarkerClickListener(this);
        mMap.setOnInfoWindowClickListener(this);
        new MapLoad().execute();
    }

/*
    public void onSearch(View view)
    {
        EditText dest=(EditText)findViewById(R.id.destination);
        String location=dest.getText().toString();

        if (location!=null || !location.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            List<Address> addressList = null;
            try {
                addressList = geocoder.getFromLocationName(location, 1);
                Address address = addressList.get(0);
                LatLng latLng=new LatLng(address.getLatitude(),address.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }*/
    @Override
    public boolean onMarkerClick(Marker marker) {

        marker.showInfoWindow();
        return  false;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        Intent intent1 = new Intent(MapsActivity.this, HouseInfoGuest.class);

        String title = marker.getTitle();
        intent1.putExtra("title",title);
        startActivity(intent1);

    }
    public class MapLoad extends AsyncTask<Void,Void,Void>
    {
        public void loadMap()
        {
            FirebaseDatabase mdatabase=FirebaseDatabase.getInstance();
            DatabaseReference mref=mdatabase.getReference().child("houses");
            mref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot obj:dataSnapshot.getChildren()){
                        Map<String,Object> house= (HashMap<String, Object>) obj.getValue();
                        double longitude=Double.parseDouble(house.get("longitude").toString());
                        double latitude=Double.parseDouble(house.get("latitude").toString());
                        LatLng mark = new LatLng(latitude,longitude);
                        mMap.addMarker(new MarkerOptions().position(mark).icon(BitmapDescriptorFactory
                                .defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                .snippet(house.get("house_owner").toString()).title(obj.getKey().toString()));
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(mark));

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
        @Override
        protected Void doInBackground(Void... voids) {
            loadMap();
            return null;
        }
    }
}
