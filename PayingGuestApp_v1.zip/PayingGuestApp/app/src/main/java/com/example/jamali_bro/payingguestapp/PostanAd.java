package com.example.jamali_bro.payingguestapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.IOException;
import java.util.Map;

/**
 * Created by jamali_bro on 11/18/2017.
 */

public class PostanAd extends AppCompatActivity{
    Button loc;
    EditText roomsav;
    EditText rperroom;
    EditText cno;
    String house_address;
    double longit,lat;
    Button button;
    private Uri imageUri;
    ImageButton imgButton;
    private final int IMAGE_REQUEST=5;
    private final int PLACE_PICKER_REQUEST = 1;

    public FirebaseDatabase mdatabase;
    private StorageReference storageReference;
    protected ProgressDialog mbar;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.postanad);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Host Menu");
        toolbar.setTitleMarginStart(20);
        toolbar.setSubtitle("Post New Ad");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        loc=(Button) findViewById(R.id.location);
        imgButton=(ImageButton)findViewById(R.id.imageButton);
        roomsav=(EditText) findViewById(R.id.roomsavailable);
        rperroom=(EditText) findViewById(R.id.rentperroom);
        cno=(EditText)findViewById(R.id.contactnumber);
        button=(Button)findViewById(R.id.post);
        mbar=new ProgressDialog(this);
        mdatabase=FirebaseDatabase.getInstance();
        storageReference= FirebaseStorage.getInstance().getReference().child("House Images");


        button=(Button)findViewById(R.id.post);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                new AdPost().execute();

            }
        });
        imgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gallery=new Intent(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/*");
                startActivityForResult(gallery,IMAGE_REQUEST);

            }
        });

    }
    private boolean validateForm() {
        boolean result = true;
        if (TextUtils.isEmpty(loc.getText().toString())) {
            loc.setError("Required");
            result = false;
        } else {
            loc.setError(null);
        }

        if (TextUtils.isEmpty(roomsav.getText().toString())) {
            roomsav.setError("Required");
            result = false;
        } else {
            roomsav.setError(null);
        }

        if (TextUtils.isEmpty(cno.getText().toString())) {
            cno.setError("Required");
            result = false;
        } else {
            cno.setError(null);
        }
        if (TextUtils.isEmpty(rperroom.getText().toString())) {
            rperroom.setError("Required");
            result = false;
        } else {
            rperroom.setError(null);
        }
        if(imageUri==null)
        {
            Toast.makeText(this.getApplicationContext(),"Image Required",Toast.LENGTH_LONG).show();
            result=false;
        }
        return result;
    }

    public void startPlacePickerActivity(View view)
    {

        PlacePicker.IntentBuilder intentBuilder=new PlacePicker.IntentBuilder();
        try
        {
            Intent placepicker= intentBuilder.build(this);
            startActivityForResult(placepicker,PLACE_PICKER_REQUEST);


        }
        catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        }
        catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PLACE_PICKER_REQUEST  && resultCode == RESULT_OK) {

            Place place = PlacePicker.getPlace(data, this);
            LatLng location=place.getLatLng();

            loc.setVisibility(View.VISIBLE);
            loc.setText(place.getName());
            longit=place.getLatLng().longitude;
            lat=location.latitude;
            house_address=place.getName().toString()+place.getAddress().toString();
        }
        else if(requestCode == IMAGE_REQUEST  && resultCode == RESULT_OK)
        {
            imageUri=data.getData();
            imgButton.setImageURI(imageUri);
        }


        else
        {
            Log.i("api", "onActivityResult: failed");
        }
    }

    public class AdPost extends AsyncTask<Void,Void,Void>
    {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (!validateForm()) {
                return;
            }
            mbar.setMessage("Posting Your Ad...");
            mbar.show();

        }

        @Override
        protected Void doInBackground(Void... voids) {

            FirebaseUser houseOwner= FirebaseAuth.getInstance().getCurrentUser();
            final String userId=houseOwner.getUid();
            mdatabase.getReference().child("users").
                    child(userId)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    Host host=dataSnapshot.getValue(Host.class);
                    if (host == null){
                        Toast.makeText(PostanAd.this,
                                "Error: could not fetch user.",
                                Toast.LENGTH_SHORT).show();
                    } else {

                        new AddHouse().execute(userId,host.getName());


                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }

    public class AddHouse extends AsyncTask<String,Void,Void>
    {
        public void writeNewHouse(final String id, final String originalId)
        {

            final DatabaseReference payingguestref=mdatabase.getReference().child("houses");
            StorageReference filepath=storageReference.child(imageUri.getLastPathSegment());
            filepath.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Uri downloadUri=taskSnapshot.getDownloadUrl();
                    String key=id;
                    float houseRent=Float.parseFloat(rperroom.getText().toString());
                    int no_of_rooms=Integer.parseInt(roomsav.getText().toString());
                    String contactNo=cno.getText().toString();
                    House house=new House(key,originalId,houseRent,no_of_rooms,house_address,contactNo,longit,lat
                            ,downloadUri.toString());
                    payingguestref.push().setValue(house);
                }
            });

        }
        @Override
        protected Void doInBackground(String... strings) {
            writeNewHouse(strings[0],strings[1]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            mbar.setMessage("Ad Successfully Posted");

            mbar.dismiss();
            Intent post=new Intent(PostanAd.this,HostActivity.class);
            startActivity(post);
        }
    }

}
