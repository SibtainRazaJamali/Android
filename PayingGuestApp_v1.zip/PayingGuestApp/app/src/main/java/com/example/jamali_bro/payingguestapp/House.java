package com.example.jamali_bro.payingguestapp;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jamali-bro on 11/12/2017.
 */

public class House {
    public String getImageString() {
        return imageString;
    }

    public void setImageString(String imageString) {
        this.imageString = imageString;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    private String imageString;
    private String house_owner;
    private float house_rent;
    private int no_of_rooms;
    private String house_address;
    private String contact_no;
    private double longitude;
    private double latitude;
    private String ownerId;
    public House()
    {

    }
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("userName", house_owner);
        result.put("rent",house_rent);
        result.put("NoOfRooms",no_of_rooms);
        result.put("address",house_address);
        result.put("contactNo",contact_no);
        result.put("longitude",longitude);
        result.put("latitude",latitude);
        result.put("UserId",ownerId);
        return result;
    }

    public House(String ownerid,String house_owner, float house_rent, int no_of_rooms, String house_address, String contact_no, double longit, double lat,String filePath) {
        this.ownerId=ownerid;
        this.house_owner = house_owner;
        this.house_rent = house_rent;
        this.no_of_rooms = no_of_rooms;
        this.house_address = house_address;
        this.contact_no = contact_no;
        this.latitude=lat;
        this.longitude=longit;
        this.imageString=filePath;
    }

    public String getOwnerId()
    {
        return ownerId;
    }
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getHouse_owner() {
        return house_owner;
    }

    public void setHouse_owner(String house_owner) {
        this.house_owner = house_owner;
    }

    public float getHouse_rent() {
        return house_rent;
    }

    public void setHouse_rent(float house_rent) {
        this.house_rent = house_rent;
    }

    public int getNo_of_rooms() {
        return no_of_rooms;
    }

    public void setNo_of_rooms(int no_of_rooms) {
        this.no_of_rooms = no_of_rooms;
    }

    public String getHouse_address() {
        return house_address;
    }

    public void setHouse_address(String house_address) {
        this.house_address = house_address;
    }

}
