package com.example.jamali_bro.payingguestapp;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Jamali-bro on 11/29/2017.
 */

public class HouseInfoGuest extends AppCompatActivity {
    TextView owner,rent,contact,rooms;
    ImageView pic;
    public String key;
    float yourFloat;
    Intent back;
    Bundle bundlel;
    int room;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.house_info);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("House Info");
        toolbar.setTitleMarginStart(120);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        owner=(TextView) findViewById(R.id.owner);
        rent=(TextView) findViewById(R.id.rent);
        contact=(TextView)findViewById(R.id.phone);
        rooms=(TextView)findViewById(R.id.roomscount);
        pic=(ImageView)findViewById(R.id.imageView2);
        back=getIntent();
        //Log.v("key",back.getStringExtra("title"));
        if(back.getStringExtra("title")!=null) {
            new InfoLoad().execute(back.getStringExtra("title"));
        }
        else {
            Bundle bundle1 = back.getExtras();
            yourFloat = bundle1.getFloat("rent");
            room=bundle1.getInt("rooms");
            owner.setText(back.getStringExtra("owner").toString());
            rent.setText(yourFloat+" Rs");
            contact.setText(contact.getText()+back.getStringExtra("contact").toString());
            rooms.setText(room+" ");
            setPic(getApplicationContext(),back.getStringExtra("image").toString());
        }

    }
    public void setPic(Context context, String imgString)
    {
        Picasso.with(context).load(imgString).into(pic);
    }
    public class InfoLoad extends AsyncTask<String,Void,Void>
    {
        @Override
        protected Void doInBackground(final String... strings) {
            FirebaseDatabase mdatabase=FirebaseDatabase.getInstance();
            DatabaseReference mref=mdatabase.getReference().child("houses");
            mref.addListenerForSingleValueEvent(new ValueEventListener()
            {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot obj:dataSnapshot.getChildren()){
                        if (obj.getKey().equals(strings[0]))
                        {
                            Map<String,Object> house= (HashMap<String, Object>) obj.getValue();
                            owner.setText(house.get("house_owner").toString());
                            rent.setText(house.get("house_rent").toString()+" Rs");
                            contact.setText(contact.getText()+house.get("contact_no").toString());
                            rooms.setText(house.get("no_of_rooms").toString()+" ");
                            setPic(getApplicationContext(),house.get("imageString").toString());
                            //Log.v("data",house.get("userName").toString());
                        }
                        else
                        {
                            Log.v("data",obj.getKey());
                        }

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            return null;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {

        getMenuInflater().inflate(R.menu.main_menu3, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId()==R.id.home_view){
            Intent intent=new Intent(HouseInfoGuest.this,MainActivity.class);
            startActivity(intent);
        }
        else if(item.getItemId()==R.id.home_search){
            Intent intent=new Intent(HouseInfoGuest.this,MapsActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}
