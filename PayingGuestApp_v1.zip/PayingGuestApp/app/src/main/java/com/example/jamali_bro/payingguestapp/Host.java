package com.example.jamali_bro.payingguestapp;

/**
 * Created by Jamali-bro on 11/24/2017.
 */

public class Host {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    private String email;

    public Host()
    {

    }
    public Host(String userName,String mail){
        name=userName;
        email=mail;

    }
}
