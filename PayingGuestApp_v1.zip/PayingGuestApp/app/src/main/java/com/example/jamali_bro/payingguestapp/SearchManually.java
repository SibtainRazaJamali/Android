package com.example.jamali_bro.payingguestapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;


/**
 * Created by jamali_bro on 11/18/2017.
 */

public class SearchManually extends AppCompatActivity{

    private RecyclerView houselist;
    protected DatabaseReference mref;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchmanually);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Manual Search");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mref= FirebaseDatabase.getInstance().getReference().child("houses");
        houselist=(RecyclerView)findViewById(R.id.recycler2);
        houselist.setHasFixedSize(true);
        houselist.setLayoutManager(new LinearLayoutManager(this));

    }
    @Override
    protected void onStart()
    {
        super.onStart();
        mref= FirebaseDatabase.getInstance().getReference().child("houses");

        //Query allHouses=mref.child("house_owner").equalTo(FirebaseAuth.getInstance().getUid());
        FirebaseRecyclerAdapter<House,HostActivity.HouseHolder> recyclerAdapter= new FirebaseRecyclerAdapter<House, HostActivity.HouseHolder>(
                House.class,R.layout.house_object,HostActivity.HouseHolder.class,mref
        ) {
            @Override
            protected void populateViewHolder(HostActivity.HouseHolder viewHolder, final House model, int position) {


                    viewHolder.getItemId();
                    viewHolder.setRooms(String.valueOf(model.getNo_of_rooms()));
                    viewHolder.setRent(String.valueOf(model.getHouse_rent()));
                    viewHolder.setAddress(model.getHouse_address());
                    viewHolder.setImage(getApplicationContext(),model.getImageString());
                    viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent1 = new Intent(SearchManually.this, HouseInfoGuest.class);

                            intent1.putExtra("contact",model.getContact_no());
                            intent1.putExtra("rent",model.getHouse_rent());
                            intent1.putExtra("image",model.getImageString());
                            intent1.putExtra("rooms",model.getNo_of_rooms());
                            intent1.putExtra("address",model.getHouse_address());
                            intent1.putExtra("owner",model.getHouse_owner());
                            startActivity(intent1);
                        }
                    });


            }

        };
        recyclerAdapter.notifyDataSetChanged();
        houselist.setAdapter(recyclerAdapter);

    }
    public static class HouseHolder extends RecyclerView.ViewHolder{

        public View mView;
        public HouseHolder(View itemView) {
            super(itemView);
            mView=itemView;
        }
        public void setRooms(String rooms)
        {
            TextView roomCount=(TextView) mView.findViewById(R.id.hnoOfRooms);
            roomCount.setText("Number Of Rooms : "+rooms);
        }
        public void setRent(String rent)
        {
            TextView hrent=(TextView)mView.findViewById(R.id.hrent);
            hrent.setText("House Rent : "+rent);
        }
        public void setAddress(String address)
        {
            TextView haddress=(TextView)mView.findViewById(R.id.haddress);
            haddress.setText("House Address : "+address);
        }
        public void setImage(Context ctx, String imgString){
            ImageView himage=(ImageView)mView.findViewById(R.id.himg);
            Picasso.with(ctx).load(imgString).into(himage);

        }

    }
}
