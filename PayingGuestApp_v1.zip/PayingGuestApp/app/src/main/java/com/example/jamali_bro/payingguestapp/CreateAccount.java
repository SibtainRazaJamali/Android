package com.example.jamali_bro.payingguestapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static android.R.attr.button;

/**
 * Created by jamali_bro on 11/18/2017.
 */

public class CreateAccount extends AppCompatActivity {
    EditText userName;
    EditText pass;
    EditText emailId;
    Button button1;
    private ProgressDialog mbar;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createaccount);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        //toolbar.setLogo(R.drawable.launch);
        toolbar.setTitle("New Account");
        toolbar.setSubtitle("Enter Info");
        toolbar.setTitleMarginStart(120);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mbar=new ProgressDialog(this);
        userName=(EditText)findViewById(R.id.username);
        pass=(EditText)findViewById(R.id.password);
        emailId=(EditText)findViewById(R.id.email);
        mAuth=FirebaseAuth.getInstance();
        button1=(Button)findViewById(R.id.create);
        mDatabase=FirebaseDatabase.getInstance();
        button1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                createAccount();
            }
        });
    }

    private boolean validateForm() {
        boolean result = true;
        if (TextUtils.isEmpty(emailId.getText().toString())) {
            emailId.setError("Required");
            result = false;
        } else {
            emailId.setError(null);
        }

        if (TextUtils.isEmpty(pass.getText().toString())) {
            pass.setError("Required:at least 6 characters");
            result = false;
        } else {
            pass.setError(null);
        }
        if (TextUtils.isEmpty(userName.getText().toString())) {
            userName.setError("Required");
            result = false;
        } else {
            userName.setError(null);
        }
        return result;
    }
    public void createAccount()
    {

        if (!validateForm()) {
            return;
        }
        mbar.setMessage("Creating Account");
        mbar.show();
        final String email,password;
        email=emailId.getText().toString();
        password=pass.getText().toString();

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            String userId=user.getUid();
                            new AccountCreator().execute(userId,email);
                            Toast.makeText(CreateAccount.this, "Account Created Successfully.",
                                    Toast.LENGTH_SHORT).show();
                            mbar.dismiss();
                        } else {

                            mbar.dismiss();
                            Toast.makeText(CreateAccount.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();

                        }


                    }
                });
    }
    public class AccountCreator extends AsyncTask<String,Void,Void>{

        public void createNewUser(String newUser,String email) {


            String username = userName.getText().toString();

            Host user = new Host(username, email);
            mDatabase.getReference().child("users").child(newUser).setValue(user);

        }
        @Override
        protected Void doInBackground(String... views) {
            createNewUser(views[0],views[1]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Intent intent=new Intent(CreateAccount.this,HostActivity.class);
            startActivity(intent);
        }
    }
}
