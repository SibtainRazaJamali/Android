package com.example.jamali_bro.payingguestapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

/**
 * Created by Jamali_bro on 10/29/2017.
 */

public class HostActivity extends AppCompatActivity {
    Button b1;
    Button bt;
    private RecyclerView houselist;

    protected DatabaseReference mref;
    protected Query allhouses;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.host_activity);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Host Menu");
        toolbar.setTitleMarginStart(30);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        FirebaseUser houseOwner= FirebaseAuth.getInstance().getCurrentUser();
        final String userId=houseOwner.getUid();
        mref= FirebaseDatabase.getInstance().getReference().child("houses");
        houselist=(RecyclerView)findViewById(R.id.recycler);
        houselist.setHasFixedSize(true);
        houselist.setLayoutManager(new LinearLayoutManager(this));


        //allhouses = mref.orderByChild("UserId").equalTo(userId);
       /* b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HostActivity.this, CreateAccount.class);
                startActivity(intent);
            }
        });
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HostActivity.this,Login.class);
                startActivity(intent);
            }
        });*/
    }
    @Override
    protected void onStart()
    {
        super.onStart();
        mref= FirebaseDatabase.getInstance().getReference().child("houses");

        Query allHouses=mref.orderByChild("ownerId").equalTo(FirebaseAuth.getInstance().getUid());
        FirebaseRecyclerAdapter<House,HouseHolder> recyclerAdapter= new FirebaseRecyclerAdapter<House, HouseHolder>(
                House.class,R.layout.house_object,HouseHolder.class,allHouses
        ) {
            @Override
            protected void populateViewHolder(HouseHolder viewHolder, final House model, int position) {
                Log.v("item no",mref.child("houses").getKey()+"");
                    viewHolder.setRooms(String.valueOf(model.getNo_of_rooms()));
                    viewHolder.setRent(String.valueOf(model.getHouse_rent()));
                    viewHolder.setAddress(model.getHouse_address());
                    viewHolder.setImage(getApplicationContext(),model.getImageString());
                    viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent1 = new Intent(HostActivity.this, HouseInfo.class);

                            intent1.putExtra("contact",model.getContact_no());
                            intent1.putExtra("rent",model.getHouse_rent());
                            intent1.putExtra("image",model.getImageString());
                            intent1.putExtra("rooms",model.getNo_of_rooms());
                            intent1.putExtra("address",model.getHouse_address());
                            intent1.putExtra("owner",model.getHouse_owner());
                            startActivity(intent1);
                        }
                    });


            }

        };
        recyclerAdapter.notifyDataSetChanged();

        houselist.setAdapter(recyclerAdapter);

    }
    public static class HouseHolder extends RecyclerView.ViewHolder{

        public View mView;
        public HouseHolder(View itemView) {
            super(itemView);
            mView=itemView;
        }
        public void setRooms(String rooms)
        {
            TextView roomCount=(TextView) mView.findViewById(R.id.hnoOfRooms);
            roomCount.setText("Number Of Rooms : "+rooms);
        }
        public void setRent(String rent)
        {
            TextView hrent=(TextView)mView.findViewById(R.id.hrent);
            hrent.setText("House Rent : "+rent);
        }
        public void setAddress(String address)
        {
            TextView haddress=(TextView)mView.findViewById(R.id.haddress);
            haddress.setText("House Address : "+address);
        }
        public void setImage(Context ctx,String imgString){
            ImageView himage=(ImageView)mView.findViewById(R.id.himg);
            Picasso.with(ctx).load(imgString).into(himage);

        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId()==R.id.action_add)
        {
            Intent intent=new Intent(HostActivity.this,PostanAd.class);
            startActivity(intent);
        }
        else if (item.getItemId()==R.id.home_button){
            Intent intent=new Intent(HostActivity.this,MainActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}

